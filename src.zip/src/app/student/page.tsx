'use client';

import React, { useState, useEffect } from 'react';
import { IEvent, IParticipant } from '@/lib/types';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Spinner from '@/components/ui/Spinner';
import QrCodeDisplay from '@/components/student/QrCodeDisplay';

export default function StudentPage() {
  // State for the form
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [selectedEventId, setSelectedEventId] = useState('');
  
  // State for managing UI
  const [allEvents, setAllEvents] = useState<IEvent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // State for the result
  const [foundParticipant, setFoundParticipant] = useState<IParticipant | null>(null);

  // Fetch all events on component mount for the dropdown
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const res = await fetch('/api/events');
        const data = await res.json();
        if (data.success) {
          setAllEvents(data.data);
          // Automatically select the first event if one exists
          if (data.data.length > 0) {
            setSelectedEventId(String(data.data[0]._id));
          }
        }
      } catch (err) {
        setError('Failed to load events.');
      }
    };
    fetchEvents();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setFoundParticipant(null); // Clear previous results

    try {
      // First, try to find an existing participant for this email+event
      const findRes = await fetch('/api/participants/find', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), eventId: selectedEventId }),
      });

      const findResult = await findRes.json();

      if (findRes.ok && findResult.success) {
        // Participant exists — show their QR
        setFoundParticipant(findResult.data);
      } else {
        // Participant not found — try to create one (requires name)
        if (!name.trim()) {
          throw new Error('Name is required to register a new participant.');
        }

        const createRes = await fetch('/api/participants', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: name.trim(), email: email.trim(), eventId: selectedEventId }),
        });

        const createResult = await createRes.json();
        if (!createRes.ok || !createResult.success) {
          throw new Error(createResult.error || 'Failed to create participant');
        }

        setFoundParticipant(createResult.data);
      }

    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsLoading(false);
    }
  };

  const getEventName = (id: string) => {
    return allEvents.find(event => String(event._id) === id)?.name || 'Event';
  };

  return (
    <div className="dark min-h-screen bg-black text-gray-300 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        
        {/* If participant is NOT found, show the form */}
        {!foundParticipant ? (
          <form 
            onSubmit={handleSubmit} 
            className="bg-gray-900 p-8 rounded-2xl border border-gray-800 shadow-xl space-y-6"
          >
            <h1 className="text-3xl font-bold text-center text-orange-500 mb-4">
              Get Your QR Code
            </h1>
            <p className="text-center text-gray-400">
              Enter your email and select your event to generate your unique ticket.
            </p>
            
            <Select
              id="event"
              label="Select Event"
              value={selectedEventId}
              onChange={(e) => setSelectedEventId(e.target.value)}
              disabled={allEvents.length === 0}
            >
              {allEvents.length === 0 ? (
                <option>Loading events...</option>
              ) : (
                allEvents.map((event) => (
                  <option key={String(event._id)} value={String(event._id)}>
                    {event.name} ({new Date(event.date).toLocaleDateString()})
                  </option>
                ))
              )}
            </Select>

            <Input
              id="name"
              label="Your Name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Full name"
            />

            <Input
              id="email"
              label="Your Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)} // Corrected this line
              placeholder="you@example.com"
              required
            />
            
            {error && <p className="text-red-500 text-sm text-center">{error}</p>}

            <Button type="submit" variant="primary" className="w-full" disabled={isLoading}>
              {isLoading ? <Spinner size={20} /> : 'Generate QR Code'}
            </Button>
          </form>
        ) : (
          // If we FOUND the participant, show the QR code component instead
          <QrCodeDisplay
            participantId={String(foundParticipant._id)}
            participantName={foundParticipant.name}
            eventName={getEventName(String(foundParticipant.eventId))}
          />
        )}
      </div>
    </div>
  );
}

