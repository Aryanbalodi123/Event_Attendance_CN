// src/lib/types.ts
import { Types } from 'mongoose';

export interface IParticipant {
  _id?: string | Types.ObjectId;
  name: string;
  email: string;
  eventId: string | Types.ObjectId;
  attended: boolean;
  createdAt?: Date | string;
  updatedAt?: Date | string;
}

export interface IEvent {
  _id?: string | Types.ObjectId;
  name: string;
  date: Date | string;
  location: string;
  description?: string;
  participants: (string | Types.ObjectId)[];
  createdAt?: Date | string;
  updatedAt?: Date | string;
}